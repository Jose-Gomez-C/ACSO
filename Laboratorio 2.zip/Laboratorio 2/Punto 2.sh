#!bin/sh
clear
resultado=$(grep -r -i $1 $2)
echo $resultado 
