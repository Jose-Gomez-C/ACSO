!#/bin/bash
clear
Find $1 -perm $2