#include<stdio.h>
#include<stdlib.h>
int main(){
int valorU, valorU2;
printf("introduzca el primer numero entero: ");
scanf("%d",&valorU);
printf("Introduzca el segundo numero entero; ");
scanf("%d",&valorU2);
printf("Gracia la suma es: %d\n",valorU+valorU2);
return 0;
}

